FreeType 2.10.0
=========================
###### Windows binaries (DLL) of FreeType (win32/win64)

Compiled with VS Express 2015  
Compatible with Windows XP, Vista, 7, 8, 10

> *freetype.dll* uses the *Universal CRT* and therefore **_requires_** Visual C++ 2017 Redistributable to be present on system (*VC++ 2017 Redistributable supersedes VC++ 2015 Redistributable*).

| filename | sha256 |
| :-- | :-- |
| win32\\**freetype.dll** | `D039F727E82A4570883DBA2069F9DD95518BA580F16F891FCC5FD6C07624BF35` |
| win32\\**freetype.lib** | `28B2D11BC7A4648696C96675771A32AEFE33FC7D13E83A416AB0CCD30CA7B79F` |
| win64\\**freetype.dll** | `58AAE1F69EA5C2ADCA3CF0314D01E14353F674755B9D1098C1EBBF478207B672` |
| win64\\**freetype.lib** | `158C6FEF7BD18028034AE2E5405CA118EA0476B7298935560D7D7A7730D6390E` |
